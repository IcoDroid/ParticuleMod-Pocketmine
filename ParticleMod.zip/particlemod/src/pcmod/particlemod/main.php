<?php

namespace pcmod\particlemod;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\Player;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\network\mcpe\protocol\AnimatePacket;

class main extends PluginBase implements Listener
{
  public $players = [];
  
  public function onEnable()
  {
    $this->getlogger()->info("le plugin a bien �t� activ�");
    $this->getServer()->getPluginManager()->registerEvents($this, $this);
  }

  public function onDisable()
  {
    $this->getlogger()->info("le plugin a bien �t� desactiv�");
  }

  public function onCommand(CommandSender $sender, Command $cmd, $label, array $args) : bool{
    if($cmd->getName()=="pcmod") {
      if ($sender instanceof Player) {
        if (!empty($args[0])) {
          if (is_numeric($args[0])) {
            if ($args[0] >= 0) {
              $this->players[$sender->getName()] = (int)$args[0];
              $sender->sendMessage("Tu a mis le pcmod a " . (int)$args[0]);
              return true;
            } else {
              $sender->sendMessage("tu peux pas mettre un nombre inferieur a 0");
              return false;
            }
          } else {
            $sender->sendMessage("tu dois mettre un nombre");
            return false;
          }
        } else {
          $sender->sendMessage("/pcmod [nombre]");
          return false;
        }
      } else {
        $sender->sendMessage("FDP T CON USE PAS UN PARTICULE MOD DANS LA CONSOLE");
        return false;
      }
    }
    return false;
  }

  public function onParticles(EntityDamageByEntityEvent $event) : void {
    $player = $event->getEntity();
    $damager = $event->getDamager();

    if (isset($this->players[$damager->getName()])) {
      $n = $this->players[$damager->getName()];
      if ($n > 0) {
         if ($player instanceof Player and $damager instanceof Player) {
          for ($i = 1; $i <= $n; $i++) {
            $pk = new AnimatePacket();
            $pk->action = AnimatePacket::ACTION_CRITICAL_HIT;     
            $pk->entityRuntimeId = $player->getId();
            $damager->dataPacket($pk);
          }
        }
      }
    }
  }
}